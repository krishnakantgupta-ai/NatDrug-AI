# Upload to your EXISTING NatDrug-AI repository

Repository: https://github.com/krishnakantgupta-ai/NatDrug-AI

This archive contains **`research_v2/`**, a standalone, additive research-study folder. Do **not** replace your original `app.py`, `README.md`, or `LICENSE` with this research add-on.

## Easiest way using Terminal on your Mac

1. Extract `NatDrugAI_v2_GitHub_Upload.zip` into Downloads.
2. Clone your public GitHub repo (skip the `git clone` command if you already have the project checked out):

```bash
cd ~/Downloads
git clone https://github.com/krishnakantgupta-ai/NatDrug-AI.git
cd NatDrug-AI
cp -R ~/Downloads/NatDrugAI_v2_GitHub_Upload/research_v2 ./research_v2
git add research_v2
git status
git commit -m "Add NatDrug-AI v2 validation, screening and reproducibility research"
git push origin main
```

If your default branch is not `main`, use the correct branch name. If `research_v2/` already exists, inspect the changes and consider `rsync -av` rather than overwriting files blindly.

3. Open `research_v2/README.md` on GitHub. Run the included results viewer notebook.

## Important public-release limitations

- This is **not** a complete replacement of the current Streamlit app. It is a validated research add-on.
- Bulk IMPPAT source exports and full 18,030-row structure-level screening data are intentionally in a separate **local-only** ZIP, because public redistribution terms were not confirmed.
- Do not upload the local-only ZIP, private reviewer comments, unpublished manuscript drafts, or institutional/private files.
- ChEMBL data are licensed CC BY-SA 3.0, requiring attribution and compatible sharing for adaptations. See `research_v2/docs/DATA_SOURCES_AND_LICENSES.md`.
- Prediction files are source-backed scientific results, but **the external natural-product EGFR validation remains blocked** pending independent original assay/source verification.
